const express = require('express');
const bodyParser = require('body-parser');
const TelegramBot = require('node-telegram-bot-api');

const token = '7834048812:AAH32UdwiDntCxljyFbxNSO-9nnlar8SRLQ';
const app = express();
const bot = new TelegramBot(token);
bot.setWebHook(`https://bot.zhixgame.com:8080/bot${token}`);

app.use(bodyParser.json());

app.post(`/bot${token}`, (req, res) => {
    bot.processUpdate(req.body);
    res.sendStatus(200);
});

bot.onText(/\/start (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const parameter = match[1];

    const captionText = `Welcome to the official world of In the Garden!\n` +
        `Your journey begins in In the Garden! 🌸\n` +
        `More than farming — it's a world of teamwork, honor, and real victories\n` +
        `Welcome to the GardenVerse! 🚀\n` + parameter;

    bot.sendPhoto(chatId, './image/botimg.jpg', {
        caption: captionText,
        reply_markup: {
            inline_keyboard: [[{
                text: "open app",
                web_app: { url: `https://in-the-garden.liara.run?code=${parameter}` }
            }]]
        }
    });
});

bot.onText(/\/start$/, (msg) => {
    const chatId = msg.chat.id;
    const captionText = `Welcome to the official world of In the Garden!\n` +
        `Your journey begins in In the Garden! 🌸\n` +
        `More than farming — it's a world of teamwork, honor, and real victories\n` +
        `Welcome to the GardenVerse! 🚀`;

    bot.sendPhoto(chatId, './image/botimg.jpg', {
        caption: captionText,
        reply_markup: {
            inline_keyboard: [[{
                text: "open app",
                web_app: { url: `https://in-the-garden.liara.run` }
            }]]
        }
    });
});

const PORT = 8080;
app.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
});
